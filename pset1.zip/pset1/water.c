#include <cs50.h>
#include <stdio.h>

int main(void)
{
 
  printf("Введите первое целое число: ");
  int x = GetInt();
  
  printf("Введите второе целое число: ");
  int y = GetInt();
  
  printf("Сумма %i и %i равна %i\n", x, y, x + y);
  
}
  