#include <stdio.h>
#include <cs50.h>

int main(void) {
int height;

do {
printf("Let's build a pyramid! How high do you want it to be?                     Please type a positive integer between 1-23 inclusive\n");
height = GetInt();
}
while (height <= 0 || height >= 23);

for (int i = 0; i < height; i++)
{
    printf(" ");

    for (int hash = 0; hash < height-1; hash++)
    {
        printf("#");
    }

    printf("\n");

  }
}